import numpy as np
import matplotlib.pyplot as plt

def main():
	data = np.genfromtxt("data.csv", delimiter=",", dtype=np.int32)
	xs = data[:,0]
	ys = data[:,1]
	#plt.plot(xs, ys)
	#plt.bar(xs, ys)
	plt.scatter(xs, ys, marker=".")
	#plt.boxplot(ys)
	plt.show()

if __name__ == "__main__":
	main()
